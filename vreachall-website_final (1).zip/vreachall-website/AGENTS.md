<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the agency pages as separate TanStack routes with shared site chrome and centralized service/contact data so navigation stays consistent.
- Export source from a clean staging folder with local copies of hosted asset bytes; never include repository metadata, installed dependencies or build output.
- Homepage sections live in src/components/home/ (Hero.tsx + Sections.tsx) and are composed in src/routes/index.tsx, so section order is controlled in one place.
- The brand logo is the single text wordmark in src/components/brand/Logo.tsx; never add image or mascot logos, so branding stays consistent.
- Service content (names, descriptions, offerings, FAQs) lives only in src/components/site/data.ts; primary services are flagged `primary` and drive nav, footer, services and pricing ordering.
- Retired service URLs stay as redirect-only route files so old links and indexed pages keep working.
