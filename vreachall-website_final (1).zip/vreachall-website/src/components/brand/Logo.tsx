import { cn } from "@/lib/utils";

type LogoProps = {
  /** Visual size of the wordmark. */
  size?: "sm" | "md" | "lg";
  /** Use "light" on dark backgrounds such as the footer. */
  tone?: "default" | "light";
  /** Show the small "Search Visibility" descriptor under the name. */
  tagline?: boolean;
  className?: string;
};

const sizes = {
  sm: { word: "text-xl", tag: "text-[8px]" },
  md: { word: "text-2xl sm:text-[1.7rem]", tag: "text-[9px]" },
  lg: { word: "text-3xl sm:text-4xl", tag: "text-[10px]" },
} as const;

/**
 * The single VReachAll logo used across the site: a text-only wordmark in the
 * brand blue and orange. Do not add image or mascot logos elsewhere.
 */
export function Logo({ size = "md", tone = "default", tagline = false, className }: LogoProps) {
  const s = sizes[size];
  return (
    <span className={cn("inline-flex flex-col leading-none", className)} role="img" aria-label="VReachAll">
      <span aria-hidden className={cn("font-display font-extrabold tracking-tight", s.word)}>
        <span className="text-gradient-orange">V</span>
        <span className={tone === "light" ? "text-ink-foreground" : "text-primary"}>Reach</span>
        <span className="text-gradient-orange">All</span>
      </span>
      {tagline && (
        <span
          aria-hidden
          className={cn(
            "mt-1 font-sans font-semibold uppercase tracking-[0.28em]",
            s.tag,
            tone === "light" ? "text-ink-foreground/60" : "text-muted-foreground",
          )}
        >
          Search Visibility
        </span>
      )}
    </span>
  );
}
