import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, ArrowDown, Check, Globe, Search, Sparkles, MessageCircleQuestion, Mic, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

type Card = { k: "search" | "ai" | "answer" | "voice"; src: string; text: string; meta?: string };
const cards: Card[] = [
  { k: "search", src: "Google", text: "best accounting software for freelancers" },
  { k: "ai", src: "ChatGPT", text: "Which CRM is easiest to set up for a 10-person team?" },
  { k: "answer", src: "Featured snippet", text: "How long does it take to see results from SEO?", meta: "Direct answer" },
  { k: "ai", src: "Perplexity", text: "Compare the top project management tools for agencies" },
  { k: "voice", src: "Voice assistant", text: "Where can I get my laptop repaired near me?" },
  { k: "search", src: "Google", text: "dentist near me open on saturday" },
  { k: "ai", src: "Gemini", text: "What should I look for in a family-friendly hotel in Goa?" },
  { k: "answer", src: "People also ask", text: "Is it worth hiring an SEO agency for a small business?", meta: "4 related questions" },
  { k: "ai", src: "Google AI Overview", text: "What is the difference between SEO and GEO?" },
  { k: "voice", src: "Voice assistant", text: "What are the best-rated coaching institutes nearby?" },
];

const cardIcon: Record<Card["k"], LucideIcon> = { search: Search, ai: Sparkles, answer: MessageCircleQuestion, voice: Mic };

function QueryCard({ c }: { c: Card }) {
  const I = cardIcon[c.k];
  if (c.k === "search")
    return (
      <div className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-xs text-muted-foreground">
        <span className="font-bold text-primary">G</span><span className="truncate">{c.text}</span><Search size={12} className="ml-auto shrink-0" />
      </div>
    );
  return (
    <div className="rounded-2xl border border-border bg-card p-3 text-xs">
      <p className="flex items-center gap-1.5 font-semibold text-muted-foreground"><I size={12} className="text-primary" />{c.src}</p>
      <p className={`mt-2 text-foreground/80 ${c.k === "ai" ? "rounded-lg bg-muted p-2" : ""}`}>{c.text}</p>
      {c.meta && <p className="mt-2 text-muted-foreground">{c.meta}</p>}
    </div>
  );
}

function Column({ offset, down }: { offset: number; down?: boolean }) {
  const list = [...cards.slice(offset), ...cards.slice(0, offset)];
  return (
    <div className="flex-1 overflow-hidden">
      <div className={`flex flex-col gap-3 ${down ? "animate-scroll-down" : "animate-scroll-up"}`}>
        {[...list, ...list].map((c, i) => <QueryCard key={i} c={c} />)}
      </div>
    </div>
  );
}

/** Abstract search/AI icon badge used as a visual accent. Not a mascot. */
export function SignalBadge({ className = "h-12 w-12", icon: I = Search }: { className?: string; icon?: LucideIcon }) {
  return (
    <span className={`grid shrink-0 place-items-center rounded-2xl bg-gradient-orange text-primary-foreground shadow-orange ${className}`} aria-hidden>
      <I className="h-1/2 w-1/2" />
    </span>
  );
}

const platforms = ["Google Search", "ChatGPT", "Google AI Overviews", "Gemini", "Perplexity", "Copilot", "Featured Snippets", "Voice Search"];

export function AuditForm({ dark }: { dark?: boolean }) {
  const [url, setUrl] = useState("");
  const navigate = useNavigate();
  const submit = (e: FormEvent) => {
    e.preventDefault();
    navigate({ to: "/contact", search: { website: url.trim() || undefined, service: "Free SEO Audit" } });
  };
  return (
    <div>
      <form onSubmit={submit} className="flex w-full items-center gap-2 rounded-2xl border border-border bg-card p-1.5 shadow-soft">
        <Globe size={18} className="ml-3 shrink-0 text-muted-foreground" />
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="yourwebsite.com" aria-label="Your website address"
          className="min-w-0 flex-1 bg-transparent py-2.5 text-sm text-foreground outline-none placeholder:text-muted-foreground" />
        <Button type="submit" variant="hero" className="rounded-xl">Get Free SEO Audit <ArrowRight /></Button>
      </form>
      <p className={`mt-3 flex flex-wrap items-center justify-center gap-3 text-xs ${dark ? "text-ink-foreground/70" : "text-muted-foreground"}`}>
        <span className="inline-flex items-center gap-1"><Check size={12} /> SEO health check</span>
        <span className="inline-flex items-center gap-1"><Check size={12} /> AI answer visibility snapshot</span>
        <span className="inline-flex items-center gap-1"><Check size={12} /> Priority next steps</span>
      </p>
    </div>
  );
}

export function Hero() {
  const [i, setI] = useState(0);
  useEffect(() => { const t = setInterval(() => setI((v) => (v + 1) % platforms.length), 2000); return () => clearInterval(t); }, []);
  return (
    <section className="relative overflow-hidden" aria-labelledby="hero-title">
      <div className="pointer-events-none absolute inset-0 flex gap-3 px-3 opacity-50 mask-fade-y" aria-hidden>
        {[0, 3, 6, 9, 2, 5, 8].map((o, k) => (
          <div key={k} className={`flex-1 ${k > 1 ? "hidden sm:flex" : "flex"} ${k > 3 ? "lg:flex hidden" : ""}`}><Column offset={o} down={k % 2 === 1} /></div>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-0 bg-hero-veil" />
      <div className="relative mx-auto flex max-w-3xl flex-col items-center px-4 pb-20 pt-16 text-center sm:pt-24">
        <div className="flex flex-wrap justify-center gap-2">
          {["SEO", "GEO", "AEO"].map((t) => (
            <span key={t} className="rounded-full border border-border bg-card px-4 py-1.5 font-display text-sm font-bold text-primary shadow-soft">{t}</span>
          ))}
        </div>
        <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">AI-first search visibility &amp; digital growth agency</p>
        <h1 id="hero-title" className="mt-5 text-5xl font-extrabold leading-[1.04] tracking-tight sm:text-6xl lg:text-7xl">
          Be Visible <span className="text-primary">Beyond Search.</span><br /> Be the <span className="text-gradient-orange">Answer</span> Everywhere.
        </h1>
        <p className="mt-7 max-w-2xl text-lg text-muted-foreground sm:text-xl">
          VReachAll helps businesses strengthen their online presence through SEO, GEO, and AEO strategies designed for the evolving world of search engines and AI-powered answer platforms.
        </p>
        <p className="mt-6 flex flex-wrap items-center justify-center gap-3 text-base text-foreground">
          Optimised for
          <span key={i} className="animate-word-in rounded-xl bg-ink px-4 py-1.5 font-display font-semibold text-ink-foreground">{platforms[i]}</span>
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Button asChild variant="hero" size="xl"><Link to="/contact" search={{ service: "Free SEO Audit" }}>Get Free SEO Audit <ArrowRight size={18} /></Link></Button>
          <Button asChild variant="outline" size="xl" className="rounded-full"><Link to="/services">Explore Our Services</Link></Button>
        </div>
        <a href="#why" className="mt-12 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground hover:text-primary">
          Why search visibility has changed <ArrowDown size={12} />
        </a>
      </div>
    </section>
  );
}
