import { useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowRight, Search, Sparkles, MessageCircleQuestion, Mic, Check, Plus, Minus, TrendingUp, FileSearch, Layers,
  LineChart, ShieldCheck, Target, ClipboardList, FileText, Code2, BarChart3, Users, Eye, Scale,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { AuditForm, SignalBadge } from "./Hero";
import { primaryServices, process, faqs } from "@/components/site/data";

export function Eyebrow({ children }: { children: string }) {
  return <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-accent">{children}</p>;
}
const card = "rounded-3xl border border-border bg-card p-6 shadow-soft";

/* 1. Why traditional SEO alone is no longer enough */
export function Problem() {
  return (
    <section id="why" className="scroll-mt-24 bg-sky" aria-labelledby="why-title">
      <div className="mx-auto max-w-6xl px-4 py-24 sm:px-6">
        <div className="mx-auto max-w-3xl text-center">
          <Eyebrow>The shift in search</Eyebrow>
          <h2 id="why-title" className="mt-4 text-3xl font-bold leading-tight sm:text-5xl">Ranking is still essential. <span className="text-muted-foreground">It just isn't the whole story anymore.</span></h2>
          <p className="mt-5 text-lg text-muted-foreground">Today a single search can return an AI summary, an answer box and a list of links — often before anyone clicks. Your visibility now depends on all three.</p>
        </div>

        <div className="mx-auto mt-14 max-w-3xl overflow-hidden rounded-3xl border border-border bg-card shadow-float">
          <div className="flex items-center gap-3 border-b border-border px-5 py-4">
            <span className="font-display text-xl font-bold text-primary">G</span>
            <div className="flex flex-1 items-center gap-2 rounded-full border border-border px-4 py-2 text-sm">how to choose an accounting firm for a startup<Search size={14} className="ml-auto text-muted-foreground" /></div>
          </div>
          <div className="space-y-4 p-5">
            <div className="rounded-2xl bg-secondary p-4">
              <p className="flex items-center gap-2 text-sm font-semibold"><Sparkles size={14} className="text-accent" /> AI-generated summary <span className="ml-auto rounded-full bg-card px-2 py-0.5 text-[10px] font-medium text-muted-foreground">GEO</span></p>
              <p className="mt-2 text-sm text-muted-foreground">Summarises the key factors and names a few firms, drawing on sources it considers clear and trustworthy.</p>
            </div>
            <div className="rounded-2xl border border-border p-4">
              <p className="flex items-center gap-2 text-sm font-semibold"><MessageCircleQuestion size={14} className="text-primary" /> People also ask <span className="ml-auto rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground">AEO</span></p>
              <ul className="mt-2 space-y-1 text-sm text-muted-foreground"><li>What should a startup expect to pay for accounting?</li><li>When does a startup need a CA firm?</li></ul>
            </div>
            <div className="rounded-2xl border border-dashed border-primary/40 p-4">
              <p className="flex items-center gap-2 text-xs text-muted-foreground"><b className="text-foreground">yourbrand.com</b> <span className="ml-auto rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium">SEO</span></p>
              <p className="mt-1 font-semibold text-primary">Startup Accounting Services | Your Brand</p>
              <p className="text-sm text-muted-foreground">The traditional organic listing — still important, now sharing the page with answers.</p>
            </div>
          </div>
          <p className="border-t border-border px-5 py-2 text-center text-[11px] text-muted-foreground">Illustrative example of a modern results page</p>
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          <div className={card}><SignalBadge className="h-10 w-10" icon={Search} /><h3 className="mt-5 text-xl font-semibold">Clicks are shared with answers.</h3><p className="mt-2 text-sm text-muted-foreground">AI summaries and answer boxes respond to many questions directly on the results page, so a good ranking alone may not earn attention.</p></div>
          <div className={card}><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><Sparkles size={18} /></span><h3 className="mt-5 text-xl font-semibold">Buyers ask AI assistants.</h3><p className="mt-2 text-sm text-muted-foreground">People increasingly use tools like ChatGPT and Gemini to shortlist options — and those tools only mention brands they can understand.</p></div>
          <div className={card}><span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/15 text-accent"><Layers size={18} /></span><h3 className="mt-5 text-xl font-semibold">Every platform reads you differently.</h3><p className="mt-2 text-sm text-muted-foreground">Search engines, AI models and voice assistants each rely on different signals, so visibility needs a joined-up strategy.</p></div>
        </div>

        <div className="mt-20 text-center">
          <Eyebrow>One question. Many places it gets answered.</Eyebrow>
          <div className="relative mx-auto mt-10 grid max-w-4xl gap-4 sm:grid-cols-2 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
            <div className="space-y-4">
              <Place icon={Search} t="Search results" d="Organic listings, local results and maps" />
              <Place icon={Sparkles} t="AI-generated answers" d="ChatGPT, Gemini, Perplexity, AI Overviews" />
            </div>
            <div className="hidden flex-col items-center gap-3 px-8 lg:flex"><div className="grid h-24 w-24 place-items-center rounded-full bg-gradient-orange text-primary-foreground shadow-orange"><Users size={32} /></div><p className="font-semibold">Your customer</p></div>
            <div className="space-y-4">
              <Place icon={MessageCircleQuestion} t="Answer boxes" d="Featured snippets and “People also ask”" />
              <Place icon={Mic} t="Voice assistants" d="Spoken, conversational questions" />
            </div>
          </div>
          <h3 className="mt-14 text-3xl font-bold sm:text-4xl">Your customers ask everywhere. <span className="text-primary">Be the answer they find.</span></h3>
        </div>
      </div>
    </section>
  );
}
function Place({ icon: I, t, d }: { icon: typeof Search; t: string; d: string }) {
  return <div className="flex items-start gap-3 rounded-2xl border border-border bg-card p-4 text-left shadow-soft"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><I size={16} /></span><div><p className="text-sm font-semibold">{t}</p><p className="text-xs text-muted-foreground">{d}</p></div></div>;
}

/* 2. SEO, GEO and AEO explained */
const pillarDetail: Record<string, { q: string; focus: string[] }> = {
  SEO: { q: "Can search engines find, understand and rank my website?", focus: ["Technical health", "Search intent", "Site structure"] },
  GEO: { q: "Do AI platforms understand and mention my brand accurately?", focus: ["Entity clarity", "Citable content", "AI answer monitoring"] },
  AEO: { q: "Are my answers clear enough to be chosen as the answer?", focus: ["Customer questions", "Snippet formatting", "Structured data"] },
};
export function Pillars() {
  return (
    <section id="services" className="scroll-mt-24 mx-auto max-w-6xl px-4 py-24 sm:px-6" aria-labelledby="pillars-title">
      <div className="mx-auto max-w-2xl text-center">
        <Eyebrow>Our core services</Eyebrow>
        <h2 id="pillars-title" className="mt-4 text-3xl font-bold sm:text-5xl">Three disciplines. One visibility strategy.</h2>
        <p className="mt-4 text-lg text-muted-foreground">Each one answers a different question about how your business is discovered.</p>
      </div>
      <div className="mt-14 grid gap-5 lg:grid-cols-3">
        {primaryServices.map((s) => {
          const p = pillarDetail[s.tag];
          return (
            <article key={s.to} className={`${card} flex flex-col`}>
              <div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary/10 text-primary"><s.icon size={22} /></span><div><p className="font-display text-2xl font-bold text-primary">{s.tag}</p><p className="text-xs font-medium text-muted-foreground">{s.name}</p></div></div>
              <p className="mt-5 rounded-2xl bg-secondary p-4 text-sm font-medium text-secondary-foreground">“{p?.q}”</p>
              <p className="mt-4 flex-1 text-sm text-muted-foreground">{s.intro}</p>
              <div className="mt-5 flex flex-wrap gap-2">{p?.focus.map((f) => <span key={f} className="rounded-full border border-border px-3 py-1 text-xs font-medium">{f}</span>)}</div>
              <Link to={s.to} className="mt-6 inline-flex items-center gap-1 text-sm font-semibold text-primary transition-all hover:gap-2">Explore {s.tag} <ArrowRight size={16} /></Link>
            </article>
          );
        })}
      </div>
    </section>
  );
}

/* 3. How SEO, GEO and AEO work together */
const layers = [
  { tag: "SEO", t: "Foundation", d: "A fast, crawlable website with pages mapped to real search intent." },
  { tag: "AEO", t: "Answers", d: "Clear question-led content and structured data that can be quoted directly." },
  { tag: "GEO", t: "AI presence", d: "Consistent brand facts and citable sources AI platforms can rely on." },
  { tag: "Measure", t: "Insight", d: "Search, snippet and AI-answer signals reviewed together." },
];
export function HowItWorks() {
  return (
    <section id="how" className="scroll-mt-24 bg-sky" aria-labelledby="how-title">
      <div className="mx-auto max-w-6xl px-4 py-24 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>How they work together</Eyebrow>
          <h2 id="how-title" className="mt-4 text-3xl font-bold sm:text-5xl">Each layer strengthens the next.</h2>
          <p className="mt-4 text-lg text-muted-foreground">Strong SEO gives AI and answer engines trustworthy pages to draw from. Clear answers make your content easier to cite. Consistent brand signals make it easier to recommend.</p>
        </div>
        <div className="mt-14 grid gap-5 lg:grid-cols-3">
          <div className="space-y-4">
            <div className={card}>
              <p className="text-sm font-semibold">What we review</p>
              <div className="mt-3 flex flex-wrap gap-2">{["Website & code", "Search Console data", "Keyword & question demand", "AI platform answers", "Competitor visibility", "Structured data"].map((x) => <span key={x} className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">{x}</span>)}</div>
            </div>
            <div className={card}>
              <p className="text-sm font-semibold">Questions we answer for you</p>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">{["Which searches should we win first?", "What do AI tools say about us today?", "Which customer questions go unanswered?"].map((x) => <li key={x} className="flex gap-2"><Check size={16} className="mt-0.5 shrink-0 text-primary" />{x}</li>)}</ul>
            </div>
          </div>
          <div className="rounded-3xl bg-ink p-6 text-ink-foreground shadow-float">
            <div className="flex items-center gap-3"><SignalBadge className="h-12 w-12" icon={Layers} /><div><p className="font-semibold">The VReachAll visibility framework</p><p className="text-xs text-ink-foreground/60">Integrated SEO · AEO · GEO</p></div></div>
            <ol className="mt-5 space-y-3 text-sm">{layers.map((l, i) => <li key={l.tag} className="rounded-xl bg-ink-foreground/10 px-4 py-3"><p className="flex items-center gap-3 font-semibold"><span className="grid h-6 w-6 place-items-center rounded-full bg-accent text-xs font-bold text-accent-foreground">{i + 1}</span>{l.t} <span className="ml-auto text-xs text-accent">{l.tag}</span></p><p className="mt-1 pl-9 text-xs text-ink-foreground/70">{l.d}</p></li>)}</ol>
          </div>
          <div className="space-y-4">
            <div className={card}>
              <p className="text-sm font-semibold">What you receive</p>
              <ul className="mt-4 space-y-3">{[
                { i: ClipboardList, t: "Visibility audit", d: "SEO, AEO and GEO findings in one report" },
                { i: Target, t: "Priority roadmap", d: "Ranked by expected impact and effort" },
                { i: FileText, t: "Content & answer briefs", d: "Built around real customer questions" },
                { i: Code2, t: "Technical & schema fixes", d: "Ready for your team or ours to implement" },
                { i: BarChart3, t: "Monthly reporting", d: "Plain-language progress and next steps" },
              ].map((s) => <li key={s.t} className="flex items-center gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-accent/15 text-accent"><s.i size={16} /></span><div><p className="text-sm font-medium">{s.t}</p><p className="text-xs text-muted-foreground">{s.d}</p></div></li>)}</ul>
            </div>
          </div>
        </div>
        <div className="mt-10 flex flex-col items-center gap-4 text-center sm:flex-row sm:justify-center">
          <p className="text-lg font-medium">One partner, one plan, every place your customers search.</p>
          <Button asChild variant="hero" className="rounded-full"><Link to="/services">Explore Our Services <ArrowRight /></Link></Button>
        </div>
      </div>
    </section>
  );
}

/* 4. How we improve discoverability */
const deliverables = [
  ["Fix what blocks discovery", "Crawl errors, slow templates and missing structured data are resolved first, because nothing else works without them."],
  ["Answer the questions that matter", "We prioritise the questions your customers actually ask and make sure each one has a clear, direct answer on your site."],
  ["Make your brand easy to describe", "Your services, locations and expertise are stated consistently so search engines and AI tools describe you correctly."],
];
export function Discoverability() {
  const [tab, setTab] = useState<"process" | "focus">("process");
  return (
    <section className="mx-auto max-w-6xl px-4 py-24 sm:px-6" aria-labelledby="disc-title">
      <div className="text-center">
        <Eyebrow>How we help</Eyebrow>
        <h2 id="disc-title" className="mt-4 text-3xl font-bold sm:text-5xl">A clear path to being discovered.</h2>
        <p className="mt-3 text-lg text-muted-foreground">Practical, prioritised work — not a checklist of everything at once.</p>
        <div className="mt-6 inline-flex rounded-full border border-border bg-card p-1 text-sm" role="tablist">
          {(["process", "focus"] as const).map((k) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`rounded-full px-4 py-1.5 font-medium ${tab === k ? "bg-ink text-ink-foreground" : "text-muted-foreground"}`}>{k === "process" ? "Our process" : "Where we focus first"}</button>)}
        </div>
      </div>
      {tab === "process" ? (
        <ol className="mx-auto mt-10 grid max-w-5xl gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {process.map((p, i) => <li key={p.t} className={card}><span className="font-display text-3xl font-extrabold text-primary">0{i + 1}</span><h3 className="mt-3 font-semibold">{p.t}</h3><p className="mt-2 text-sm text-muted-foreground">{p.d}</p></li>)}
        </ol>
      ) : (
        <div className={`${card} mx-auto mt-10 max-w-4xl`}>
          <ol className="divide-y divide-border">{deliverables.map(([t, d], i) => <li key={t} className="flex flex-col gap-2 py-4 sm:flex-row sm:items-center"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary/10 font-bold text-primary">{i + 1}</span><div className="flex-1 sm:px-3"><p className="font-medium">{t}</p><p className="text-sm text-muted-foreground">{d}</p></div></li>)}</ol>
        </div>
      )}
    </section>
  );
}

/* 5. Measuring search visibility */
const metricGroups = [
  { tag: "SEO", i: TrendingUp, t: "Organic search", l: ["Impressions and clicks", "Rankings for priority terms", "Indexed pages and crawl health", "Core Web Vitals"] },
  { tag: "AEO", i: MessageCircleQuestion, t: "Answer presence", l: ["Featured snippets held", "“People also ask” appearances", "Question coverage on your site", "Valid structured data"] },
  { tag: "GEO", i: Sparkles, t: "AI visibility", l: ["Brand mentions in AI answers", "Accuracy of brand descriptions", "Sources cited for your topics", "Competitor presence in answers"] },
];
export function Analytics() {
  return (
    <section id="measurement" className="scroll-mt-24 bg-sky" aria-labelledby="measure-title">
      <div className="mx-auto max-w-6xl px-4 py-24 sm:px-6">
        <div className="text-center">
          <div className="flex flex-wrap justify-center gap-2">{["Search Console", "Analytics", "Rank tracking", "AI answer checks", "Schema validation"].map((x) => <span key={x} className="rounded-full border border-border bg-card px-3 py-1 text-xs font-medium">{x}</span>)}</div>
          <h2 id="measure-title" className="mt-6 text-3xl font-bold sm:text-5xl">How search visibility is measured.</h2>
          <p className="mx-auto mt-3 max-w-2xl text-lg text-muted-foreground">We track signals across all three disciplines, so you can see progress in search results, answer boxes and AI platforms side by side.</p>
        </div>
        <div className="mt-12 rounded-[2rem] border border-border bg-card p-4 shadow-float sm:p-6">
          <div className="flex items-center justify-between px-2"><p className="flex items-center gap-2 font-semibold"><LineChart size={16} className="text-primary" /> Visibility report</p><span className="rounded-full bg-secondary px-3 py-1 text-xs">What we report on</span></div>
          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            {metricGroups.map((g) => (
              <div key={g.tag} className="rounded-2xl border border-border p-5">
                <p className="flex items-center gap-2 text-sm font-semibold"><g.i size={16} className="text-primary" />{g.t}<span className="ml-auto rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold text-secondary-foreground">{g.tag}</span></p>
                <ul className="mt-4 space-y-2.5 text-sm">{g.l.map((x) => <li key={x} className="flex gap-2"><Check size={16} className="mt-0.5 shrink-0 text-success" />{x}</li>)}</ul>
              </div>
            ))}
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            {[
              { i: Eye, t: "Baseline first", d: "Every engagement starts by recording where you stand today." },
              { i: FileSearch, t: "Regular checks", d: "Search data and AI answers reviewed on a set schedule." },
              { i: Scale, t: "Honest reporting", d: "What improved, what didn't, and what we'll do next." },
            ].map((x) => <div key={x.t} className="rounded-2xl bg-secondary p-4"><p className="flex items-center gap-2 text-sm font-semibold"><x.i size={16} className="text-primary" />{x.t}</p><p className="mt-1 text-xs text-muted-foreground">{x.d}</p></div>)}
          </div>
        </div>
      </div>
    </section>
  );
}

/* 6. Our commitments (replaces unverified testimonials) */
export function Commitments() {
  return (
    <section className="bg-ink py-24 text-ink-foreground" aria-labelledby="commit-title">
      <div className="mx-auto max-w-4xl px-4 text-center">
        <Eyebrow>Our commitment</Eyebrow>
        <h2 id="commit-title" className="mt-6 font-display text-2xl font-semibold leading-snug sm:text-4xl">No guaranteed rankings. No black-box tactics. Just clear, accountable work on the things that make your business easier to find.</h2>
        <div className="mt-10 grid gap-4 text-left sm:grid-cols-3">
          {[
            { i: ShieldCheck, t: "Guideline-aligned", d: "We follow search engine guidelines and avoid shortcuts that put your site at risk." },
            { i: Eye, t: "Transparent", d: "You see what we change, why we change it and how it performs." },
            { i: Target, t: "Goal-focused", d: "Work is prioritised around your business goals, not vanity metrics." },
          ].map((x) => <div key={x.t} className="rounded-2xl bg-ink-foreground/10 p-5"><x.i size={20} className="text-accent" /><p className="mt-3 font-semibold">{x.t}</p><p className="mt-1 text-sm text-ink-foreground/70">{x.d}</p></div>)}
        </div>
      </div>
    </section>
  );
}

/* 7. Comparison */
const rows = [
  ["Main goal", "Rank pages for keywords", "Be found and chosen across search, answers and AI"],
  ["Where you show up", "Organic search listings", "Listings, featured snippets, voice results and AI-generated answers"],
  ["Content approach", "Keyword-focused pages", "Question-led, clearly structured content with direct answers"],
  ["Brand information", "Often inconsistent across the web", "Consistent entity details that AI tools can rely on"],
  ["Structured data", "Optional or missing", "Reviewed and maintained as a core signal"],
  ["Competitor view", "Who ranks above you", "Who ranks, who is quoted and who AI recommends"],
  ["Reporting", "Rankings and traffic", "Search, answer presence and AI visibility together"],
];
export function Compare() {
  return (
    <section id="compare" className="scroll-mt-24 mx-auto max-w-6xl px-4 py-24 sm:px-6" aria-labelledby="compare-title">
      <div className="text-center"><Eyebrow>Traditional vs. integrated</Eyebrow><h2 id="compare-title" className="mt-4 text-3xl font-bold sm:text-5xl">SEO alone vs. <span className="text-gradient-orange">SEO + GEO + AEO.</span></h2></div>
      <div className="mt-12 overflow-x-auto rounded-3xl border border-border bg-card shadow-soft">
        <table className="w-full min-w-[640px] text-sm">
          <thead><tr className="bg-secondary text-left"><th scope="col" className="p-4 font-semibold">Area</th><th scope="col" className="p-4 font-semibold text-muted-foreground">Traditional SEO only</th><th scope="col" className="p-4 font-semibold text-primary">Integrated with VReachAll</th></tr></thead>
          <tbody>
            {rows.map(([t, w, a]) => <tr key={t} className="border-t border-border align-top"><th scope="row" className="p-4 text-left font-medium">{t}</th><td className="p-4 text-muted-foreground">{w}</td><td className="p-4 font-medium">{a}</td></tr>)}
          </tbody>
        </table>
      </div>
      <div className="mx-auto mt-10 max-w-lg space-y-4">
        <AuditForm />
        <div className="text-center"><Button asChild variant="outline" className="rounded-full"><Link to="/pricing">See engagement options <ArrowRight /></Link></Button></div>
      </div>
    </section>
  );
}

/* 8. FAQ */
export function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="scroll-mt-24 mx-auto max-w-3xl px-4 py-24 sm:px-6" aria-labelledby="faq-title">
      <div className="text-center"><Eyebrow>FAQ</Eyebrow><h2 id="faq-title" className="mt-4 text-3xl font-bold sm:text-5xl">Questions, answered.</h2></div>
      <ul className="mt-10 divide-y divide-border rounded-3xl border border-border bg-card">
        {faqs.map(([q, a], i) => (
          <li key={q}>
            <h3>
              <button onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i} className="flex w-full items-center gap-4 p-5 text-left font-sans">
                <span className="font-display text-sm text-accent">{String(i + 1).padStart(2, "0")}</span><span className="flex-1 font-semibold">{q}</span>{open === i ? <Minus size={18} /> : <Plus size={18} />}
              </button>
            </h3>
            {open === i && <p className="px-5 pb-5 pl-14 text-sm leading-relaxed text-muted-foreground">{a}</p>}
          </li>
        ))}
      </ul>
    </section>
  );
}

/* 9. Final CTA */
export function FinalCta() {
  return (
    <section className="px-4 pb-24 sm:px-6">
      <div className="mx-auto flex max-w-4xl flex-col items-center rounded-[2.5rem] bg-ink px-6 py-16 text-center text-ink-foreground shadow-float">
        <SignalBadge className="h-16 w-16 animate-float" icon={Search} />
        <h2 className="mt-6 text-3xl font-bold sm:text-5xl">See how visible your business really is.</h2>
        <p className="mt-3 max-w-xl text-ink-foreground/75">Share your website and we'll review your SEO health and how search and AI platforms currently present your brand.</p>
        <div className="mt-8 w-full max-w-lg"><AuditForm dark /></div>
        <Link to="/contact" className="mt-6 text-sm font-medium text-ink-foreground/80 underline-offset-4 hover:text-accent hover:underline">Prefer to talk first? Contact our team</Link>
      </div>
    </section>
  );
}
