import { Link } from "@tanstack/react-router";
import { Check, Search, Sparkles, MessageCircleQuestion, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";

const engagements = [
  { name: "SEO", service: "Search Engine Optimization", icon: Search, desc: "For businesses that need a strong organic search foundation.", scope: ["Technical SEO audit", "Keyword & search intent research", "On-page and architecture improvements", "Local SEO where relevant", "Organic performance reporting"] },
  { name: "GEO", service: "Generative Engine Optimization", icon: Sparkles, desc: "For brands that want to understand and improve AI answer visibility.", scope: ["AI search visibility analysis", "Brand & entity optimization", "Citation and mention analysis", "AI-ready content structure", "AI answer monitoring"] },
  { name: "AEO", service: "Answer Engine Optimization", icon: MessageCircleQuestion, desc: "For businesses whose customers ask a lot of questions before buying.", scope: ["Customer question research", "Answer-focused content", "FAQ & featured snippet optimization", "Schema review", "Voice search readiness"] },
  { name: "Integrated", service: "Integrated SEO + GEO + AEO", icon: Layers, desc: "One coordinated plan across all three disciplines.", popular: true, scope: ["Everything in SEO, GEO and AEO", "Single prioritised roadmap", "Combined visibility reporting", "Competitor visibility analysis", "Supporting content & technical work"] },
];

export function PricingSection() {
  return (
    <section id="pricing" className="mx-auto max-w-7xl px-4 py-20 sm:px-6" aria-labelledby="pricing-title">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent">Pricing</p>
        <h1 id="pricing-title" className="mt-2 text-3xl font-bold sm:text-5xl">Engagements scoped to your goals</h1>
        <p className="mt-4 text-muted-foreground">Every website, market and goal is different, so we don't sell fixed packages. Choose the area you want to focus on and we'll prepare a tailored proposal after an initial review.</p>
      </div>
      <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {engagements.map((p) => (
          <div key={p.name} className={`relative flex flex-col rounded-3xl border bg-card p-7 ${p.popular ? "border-primary shadow-soft" : "border-border"}`}>
            {p.popular && <span className="absolute -top-3 left-7 rounded-full bg-gradient-orange px-3 py-1 text-xs font-semibold text-primary-foreground">Most complete</span>}
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary"><p.icon size={20} /></span>
            <h2 className="mt-4 text-lg font-semibold">{p.name}</h2>
            <p className="text-xs font-medium text-muted-foreground">{p.service}</p>
            <p className="mt-3 text-sm text-muted-foreground">{p.desc}</p>
            <div className="mt-5 font-display text-2xl font-bold">Custom proposal</div>
            <ul className="mt-6 flex-1 space-y-2.5 text-sm">
              {p.scope.map((f) => <li key={f} className="flex gap-2"><Check size={16} className="mt-0.5 shrink-0 text-primary" />{f}</li>)}
            </ul>
            <Button asChild variant={p.popular ? "hero" : "outline"} className="mt-7 rounded-full">
              <Link to="/contact" search={{ service: p.service }}>Request a proposal</Link>
            </Button>
          </div>
        ))}
      </div>
      <p className="mx-auto mt-10 max-w-2xl text-center text-sm text-muted-foreground">Not sure where to start? Begin with a <Link to="/contact" search={{ service: "Free SEO Audit" }} className="font-medium text-primary underline-offset-4 hover:underline">free SEO audit</Link> and we'll recommend the right engagement.</p>
    </section>
  );
}
