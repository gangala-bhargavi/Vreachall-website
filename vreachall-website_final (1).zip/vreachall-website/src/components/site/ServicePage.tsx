import { Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageShell, PageHero, SectionHead, CtaBand, JsonLd } from "./SiteChrome";
import { services, process, contact, type ServiceSlug } from "./data";

function getService(to: ServiceSlug) {
  const s = services.find((x) => x.to === to);
  if (!s) throw new Error(`Unknown service: ${to}`);
  return s;
}

export function serviceHead(to: ServiceSlug) {
  const s = getService(to);
  const title = s.primary ? `${s.name} (${s.tag}) Services — VReachAll` : `${s.name} — VReachAll`;
  return {
    meta: [
      { title },
      { name: "description", content: s.intro },
      { property: "og:title", content: title },
      { property: "og:description", content: s.intro },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  };
}

export function ServicePage({ to }: { to: ServiceSlug }) {
  const s = getService(to);
  const others = services.filter((x) => x.to !== to);
  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: s.name,
    serviceType: s.name,
    description: s.intro,
    provider: { "@type": "ProfessionalService", name: "VReachAll", email: contact.email },
    ...(s.faqs.length
      ? { subjectOf: { "@type": "FAQPage", mainEntity: s.faqs.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) } }
      : {}),
  };
  return (
    <PageShell>
      <JsonLd data={schema} />
      <PageHero eyebrow={s.primary ? `Core service · ${s.tag}` : "Supporting service"} title={s.name} sub={s.intro}>
        <Button asChild variant="hero" size="xl"><Link to="/contact" search={{ service: s.name }}>{s.cta} <ArrowRight size={18} /></Link></Button>
        <Button asChild variant="outline" size="xl" className="rounded-full"><Link to="/services">All Services</Link></Button>
      </PageHero>

      <section className="mx-auto max-w-4xl px-4 pt-20 sm:px-6" aria-labelledby="overview-title">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent">Overview</p>
        <h2 id="overview-title" className="mt-2 text-3xl font-bold sm:text-4xl">Why {s.primary ? s.tag : s.name.toLowerCase()} matters</h2>
        {s.overview.map((p) => <p key={p} className="mt-4 text-lg leading-relaxed text-muted-foreground">{p}</p>)}
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <SectionHead eyebrow="What's included" title={`Our ${s.primary ? s.tag : s.name} services`} />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {s.offerings.map((o, i) => (
            <div key={o.t} className="group rounded-2xl border border-border bg-card p-6 transition hover:-translate-y-1 hover:shadow-soft">
              <span className="font-display text-sm font-bold text-accent">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-2 text-lg font-semibold">{o.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{o.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-secondary/60">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2">
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-accent">Benefits</p>
            <h2 className="mt-2 text-3xl font-bold sm:text-4xl">What you gain</h2>
            <ul className="mt-8 grid gap-4 sm:grid-cols-2">
              {s.benefits.map((b) => (
                <li key={b} className="flex items-start gap-3 rounded-xl bg-card p-4 shadow-soft">
                  <CheckCircle2 className="mt-0.5 shrink-0 text-success" size={20} /><span className="font-medium">{b}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl border border-border bg-card p-8 shadow-soft">
            <h3 className="text-xl font-semibold">How we work</h3>
            <ol className="mt-6 space-y-5">
              {process.map((p, i) => (
                <li key={p.t} className="flex gap-4">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-orange font-display text-sm font-bold text-primary-foreground">{i + 1}</span>
                  <div><p className="font-semibold">{p.t}</p><p className="text-sm text-muted-foreground">{p.d}</p></div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {s.faqs.length > 0 && (
        <section className="mx-auto max-w-3xl px-4 pt-20 sm:px-6">
          <SectionHead eyebrow="FAQ" title={`${s.tag} questions`} />
          <dl className="mt-10 divide-y divide-border rounded-3xl border border-border bg-card">
            {s.faqs.map(([q, a]) => <div key={q} className="p-6"><dt className="font-semibold">{q}</dt><dd className="mt-2 text-sm leading-relaxed text-muted-foreground">{a}</dd></div>)}
          </dl>
        </section>
      )}

      <section className="mx-auto max-w-7xl px-4 pt-20 sm:px-6">
        <SectionHead eyebrow="Explore more" title="Related services" />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {others.map((o) => (
            <Link key={o.to} to={o.to} className="rounded-2xl border border-border bg-card p-5 transition hover:-translate-y-1 hover:border-primary/40 hover:shadow-soft">
              <o.icon className="text-primary" size={22} />
              <p className="mt-3 font-semibold">{o.primary ? o.tag : o.name}</p>
              <p className="text-xs text-muted-foreground">{o.short}</p>
            </Link>
          ))}
        </div>
      </section>
      <CtaBand title={`Ready to start with ${s.primary ? s.tag : "this service"}?`} sub="Tell us about your website and goals, and we'll recommend a focused first step." />
    </PageShell>
  );
}
