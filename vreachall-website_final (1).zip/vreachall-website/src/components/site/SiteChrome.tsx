import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Menu, X, ChevronDown, Phone, Mail, MapPin, ArrowRight } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { services, primaryServices, supportingServices, contact } from "./data";

const mainNav = [
  { label: "Home", to: "/" },
  { label: "About Us", to: "/about" },
] as const;
const tailNav = [
  { label: "Case Studies", to: "/case-studies" },
  { label: "Pricing", to: "/pricing" },
  { label: "Contact", to: "/contact" },
] as const;

const linkCls = "rounded-full px-3 py-2 transition-colors hover:text-primary";
const active = { className: "text-primary" };

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [svcOpen, setSvcOpen] = useState(false);
  const close = () => { setOpen(false); setSvcOpen(false); };
  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link to="/" className="shrink-0" aria-label="VReachAll home">
          <Logo size="md" tagline />
        </Link>
        <nav aria-label="Main" className="hidden items-center gap-1 text-sm font-medium text-muted-foreground lg:flex">
          {mainNav.map((n) => (
            <Link key={n.to} to={n.to} className={linkCls} activeProps={active} activeOptions={{ exact: true }}>{n.label}</Link>
          ))}
          <div className="group relative">
            <Link to="/services" className={`${linkCls} inline-flex items-center gap-1`} activeProps={active}>
              Services <ChevronDown size={14} className="transition-transform group-hover:rotate-180" />
            </Link>
            <div className="invisible absolute left-1/2 top-full w-[38rem] -translate-x-1/2 translate-y-2 pt-3 opacity-0 transition-all duration-200 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100">
              <div className="rounded-2xl border border-border bg-card p-3 shadow-soft">
                <p className="px-3 pb-1 pt-1 text-[11px] font-semibold uppercase tracking-widest text-accent">Core services</p>
                <div className="grid grid-cols-3 gap-1">
                  {primaryServices.map((s) => (
                    <Link key={s.to} to={s.to} className="flex flex-col gap-2 rounded-xl p-3 transition-colors hover:bg-secondary">
                      <span className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><s.icon size={18} /></span>
                      <span className="block font-semibold text-foreground">{s.tag}</span>
                      <span className="block text-xs text-muted-foreground">{s.short}</span>
                    </Link>
                  ))}
                </div>
                <p className="mt-2 border-t border-border px-3 pb-1 pt-3 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">Supporting services</p>
                <div className="grid grid-cols-3 gap-1">
                  {supportingServices.map((s) => (
                    <Link key={s.to} to={s.to} className="flex items-center gap-2 rounded-xl p-3 text-xs font-medium text-foreground transition-colors hover:bg-secondary">
                      <s.icon size={14} className="shrink-0 text-primary" />{s.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
          {tailNav.map((n) => (
            <Link key={n.to} to={n.to} className={linkCls} activeProps={active}>{n.label}</Link>
          ))}
        </nav>
        <div className="hidden items-center gap-2 lg:flex">
          <Button asChild variant="ghost"><Link to="/login">Login</Link></Button>
          <Button asChild variant="hero"><Link to="/contact">Get Free SEO Audit</Link></Button>
        </div>
        <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Toggle menu" aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </Button>
      </div>
      {open && (
        <nav id="mobile-navigation" aria-label="Mobile" className="max-h-[calc(100vh-5rem)] overflow-y-auto border-t border-border bg-background px-4 py-4 lg:hidden">
          <div className="flex flex-col gap-1 text-sm font-medium">
            {mainNav.map((n) => (
              <Link key={n.to} to={n.to} onClick={close} className="rounded-lg px-3 py-2.5 hover:bg-secondary" activeProps={active} activeOptions={{ exact: true }}>{n.label}</Link>
            ))}
            <Button variant="ghost" onClick={() => setSvcOpen(!svcOpen)} aria-expanded={svcOpen} className="justify-between px-3 py-2.5 text-left">
              Services <ChevronDown size={16} className={svcOpen ? "rotate-180 transition-transform" : "transition-transform"} />
            </Button>
            {svcOpen && (
              <div className="ml-3 flex flex-col border-l border-border pl-3">
                <Link to="/services" onClick={close} className="px-3 py-2 text-muted-foreground">All Services</Link>
                {services.map((s) => (
                  <Link key={s.to} to={s.to} onClick={close} className="px-3 py-2 text-muted-foreground" activeProps={active}>
                    {s.primary ? `${s.tag} – ${s.name}` : s.name}
                  </Link>
                ))}
              </div>
            )}
            {tailNav.map((n) => (
              <Link key={n.to} to={n.to} onClick={close} className="rounded-lg px-3 py-2.5 hover:bg-secondary" activeProps={active}>{n.label}</Link>
            ))}
            <div className="mt-3 flex gap-2">
              <Button asChild variant="outline" className="flex-1"><Link to="/login" onClick={close}>Login</Link></Button>
              <Button asChild variant="hero" className="flex-1"><Link to="/contact" onClick={close}>Get Free SEO Audit</Link></Button>
            </div>
          </div>
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.4fr]">
        <div>
          <Link to="/" aria-label="VReachAll home"><Logo size="lg" tone="light" tagline /></Link>
          <p className="mt-5 max-w-xs text-sm text-ink-foreground/70">
            An AI-first search visibility agency. We help businesses get found in search results, AI-generated answers and answer engines through SEO, GEO and AEO.
          </p>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Quick Links</h2>
          <ul className="mt-4 space-y-2 text-sm text-ink-foreground/65">
            {[...mainNav, { label: "Services", to: "/services" } as const, ...tailNav].map((l) => (
              <li key={l.to}><Link to={l.to} className="hover:text-accent">{l.label}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Our Services</h2>
          <ul className="mt-4 space-y-2 text-sm text-ink-foreground/65">
            {services.map((s) => (
              <li key={s.to}><Link to={s.to} className="hover:text-accent">{s.primary ? `${s.tag} – ${s.name}` : s.name}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Contact Us</h2>
          <ul className="mt-4 space-y-3 text-sm text-ink-foreground/65">
            <li className="flex gap-2"><MapPin size={16} className="mt-0.5 shrink-0 text-accent" />{contact.address}</li>
            {contact.phones.map((p) => (
              <li key={p} className="flex gap-2"><Phone size={16} className="shrink-0 text-accent" /><a href={`tel:${p.replace(/[^+\d]/g, "")}`} className="hover:text-accent">{p}</a></li>
            ))}
            <li className="flex gap-2"><Mail size={16} className="shrink-0 text-accent" /><a href={`mailto:${contact.email}`} className="hover:text-accent">{contact.email}</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ink-foreground/10 py-5 text-center text-xs text-ink-foreground/50">
        © {new Date().getFullYear()} VReachAll. All rights reserved.
      </div>
    </footer>
  );
}

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1 animate-in fade-in duration-500">{children}</main>
      <SiteFooter />
    </div>
  );
}

export function PageHero({ eyebrow, title, sub, children }: { eyebrow: string; title: ReactNode; sub?: string; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden bg-hero">
      <div className="mx-auto max-w-4xl px-4 py-20 text-center sm:px-6 lg:py-28">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent">{eyebrow}</p>
        <h1 className="mt-3 text-4xl font-extrabold leading-tight sm:text-5xl lg:text-6xl">{title}</h1>
        {sub && <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">{sub}</p>}
        {children && <div className="mt-8 flex flex-wrap justify-center gap-3">{children}</div>}
      </div>
    </section>
  );
}

export function SectionHead({ eyebrow, title, sub }: { eyebrow: string; title: string; sub?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="text-sm font-semibold uppercase tracking-widest text-accent">{eyebrow}</p>
      <h2 className="mt-2 text-3xl font-bold sm:text-4xl">{title}</h2>
      {sub && <p className="mt-4 text-muted-foreground">{sub}</p>}
    </div>
  );
}

export function CtaBand({ title = "Ready to be found wherever your customers ask?", sub = "Start with a free SEO audit and a clear view of your visibility across search, AI answers and answer engines." }: { title?: string; sub?: string }) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="relative overflow-hidden rounded-3xl bg-ink px-6 py-14 text-center text-ink-foreground sm:px-12">
        <div className="pointer-events-none absolute inset-0 bg-hero opacity-60" />
        <div className="relative">
          <h2 className="text-3xl font-bold sm:text-4xl">{title}</h2>
          <p className="mx-auto mt-4 max-w-xl text-ink-foreground/75">{sub}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button asChild variant="hero" size="xl"><Link to="/contact">Get Free SEO Audit <ArrowRight size={18} /></Link></Button>
            <Button asChild variant="outline" size="xl" className="rounded-full border-ink-foreground/30 bg-transparent text-ink-foreground hover:bg-ink-foreground/10 hover:text-ink-foreground">
              <a href={`tel:${(contact.phones[1] ?? "").replace(/[^+\d]/g, "")}`}><Phone size={18} /> {contact.phones[1]}</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

/** Renders a JSON-LD structured data block inside the page body. */
export function JsonLd({ data }: { data: unknown }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }} />;
}
