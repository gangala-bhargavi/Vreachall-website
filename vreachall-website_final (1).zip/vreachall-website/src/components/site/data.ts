import {
  Search,
  Sparkles,
  MessageCircleQuestion,
  PenLine,
  Radar,
  Gauge,
  type LucideIcon,
} from "lucide-react";

export type ServiceSlug =
  | "/seo-services"
  | "/geo-services"
  | "/aeo-services"
  | "/ai-content-strategy"
  | "/search-intelligence"
  | "/technical-optimization";

export type Service = {
  to: ServiceSlug;
  /** Short acronym or label shown on badges, e.g. "SEO". */
  tag: string;
  name: string;
  short: string;
  icon: LucideIcon;
  /** Primary services (SEO, GEO, AEO) get top billing everywhere. */
  primary: boolean;
  intro: string;
  overview: string[];
  offerings: { t: string; d: string }[];
  benefits: string[];
  cta: string;
  faqs: [string, string][];
};

export const services: Service[] = [
  {
    to: "/seo-services",
    tag: "SEO",
    name: "Search Engine Optimization",
    short: "A strong, crawlable foundation for organic search",
    icon: Search,
    primary: true,
    intro:
      "Build the technical and content foundation that helps search engines crawl, understand and rank your website for the searches that matter to your business.",
    overview: [
      "Search engines are still where most buying journeys begin, and they are also a key source that AI assistants draw on. Our SEO work makes sure your website is technically sound, clearly structured and aligned with what your customers actually search for.",
      "We start with a detailed audit, then work through a prioritised plan covering technical health, page-level optimisation, site architecture and content gaps — so every improvement is tied to a clear reason.",
    ],
    offerings: [
      { t: "Technical SEO", d: "Crawlability, indexing, page speed, Core Web Vitals and mobile experience reviewed and improved at the code level." },
      { t: "Keyword & search intent research", d: "We map the terms your customers use to the intent behind them, so each page targets a clear purpose." },
      { t: "On-page SEO", d: "Titles, headings, body copy, images and metadata refined so each page clearly signals its topic." },
      { t: "Website architecture", d: "A logical page hierarchy and URL structure that helps both visitors and crawlers find what they need." },
      { t: "Technical audits", d: "A documented review of errors, redirects, duplicate content and indexing issues, ranked by impact." },
      { t: "Internal linking", d: "Purposeful links between related pages that spread authority and guide visitors deeper into your site." },
      { t: "Local SEO", d: "Business profile, location pages and local signals optimised for searches near your customers." },
      { t: "Content gap analysis", d: "We identify topics your audience searches for that your website does not yet cover well." },
      { t: "Organic search performance", d: "Ongoing tracking of impressions, clicks and rankings with clear reporting on what changed and why." },
    ],
    benefits: [
      "A website search engines can crawl and index without friction",
      "Pages aligned to real customer search intent",
      "A clear, prioritised roadmap instead of scattered fixes",
      "A stronger base for AI and answer engine visibility",
    ],
    cta: "Get a Free SEO Audit",
    faqs: [
      ["How long does SEO take to show results?", "SEO is a long-term investment. Technical fixes can be picked up by search engines within weeks, while ranking improvements for competitive terms usually build over several months. We set expectations based on your site's starting point."],
      ["Do you guarantee first-page rankings?", "No. No one can honestly guarantee rankings because search engines control their own results. We focus on the factors within your control and report transparently on progress."],
    ],
  },
  {
    to: "/geo-services",
    tag: "GEO",
    name: "Generative Engine Optimization",
    short: "Visibility inside AI-generated answers",
    icon: Sparkles,
    primary: true,
    intro:
      "Improve how AI platforms such as ChatGPT, Gemini, Perplexity, Copilot and Google AI Overviews understand, describe and reference your brand.",
    overview: [
      "Generative AI tools now summarise options for people before they ever click a link. If these tools misunderstand your business — or don't mention it at all — you lose consideration at the earliest stage.",
      "GEO focuses on making your brand easy for AI systems to understand and cite: consistent entity information, clear and well-structured content, and a presence on the sources these tools tend to reference. We monitor how AI answers mention you and your competitors, then act on the gaps.",
    ],
    offerings: [
      { t: "AI search visibility analysis", d: "We test how leading AI platforms respond to the questions your buyers ask and record where your brand appears." },
      { t: "Brand & entity optimization", d: "Consistent names, descriptions and facts about your business across your site and the wider web." },
      { t: "Generative search content optimization", d: "Content rewritten to be clear, factual and easy for AI systems to summarise accurately." },
      { t: "AI answer presence monitoring", d: "Regular checks of AI responses for your priority topics so changes are spotted early." },
      { t: "Brand mention & citation analysis", d: "We identify which sources AI tools reference in your space and where your brand is missing." },
      { t: "Competitor visibility analysis", d: "See which competitors AI platforms mention for your topics and understand why." },
      { t: "AI-ready content structure", d: "Headings, summaries, definitions and comparisons organised in formats AI tools can parse reliably." },
    ],
    benefits: [
      "A clearer picture of how AI platforms describe your brand",
      "More accurate and consistent brand information online",
      "Content structured for AI summarisation and citation",
      "Early warning when AI answers about your market change",
    ],
    cta: "Request a GEO Visibility Review",
    faqs: [
      ["Can you guarantee my brand will be cited by ChatGPT or Gemini?", "No. AI platforms decide what they include in each answer, and responses vary by user and over time. GEO improves the signals that make accurate mentions more likely and gives you visibility into what is happening."],
      ["Which AI platforms do you review?", "We typically review ChatGPT, Google Gemini, Google AI Overviews, Perplexity and Microsoft Copilot, and we can adjust the list to the platforms your customers use."],
    ],
  },
  {
    to: "/aeo-services",
    tag: "AEO",
    name: "Answer Engine Optimization",
    short: "Clear, direct answers to customer questions",
    icon: MessageCircleQuestion,
    primary: true,
    intro:
      "Turn the questions your customers ask into clear, direct, well-structured answers that are ready for featured snippets, voice assistants and answer engines.",
    overview: [
      "Many searches are questions: how much, which is best, how does it work, is it right for me. Answer engines and voice assistants reward pages that answer these questions plainly and quickly.",
      "AEO is about finding those questions, answering them in a format that machines and people can read at a glance, and supporting those answers with structured data so their meaning is unambiguous.",
    ],
    offerings: [
      { t: "Customer question research", d: "We gather the real questions people ask about your products, services and industry." },
      { t: "Answer-focused content", d: "Pages and sections that lead with a direct answer, then add the detail people need to decide." },
      { t: "FAQ optimization", d: "FAQ sections planned around genuine questions, written concisely and placed where they help most." },
      { t: "Featured snippet optimization", d: "Definitions, lists, steps and tables formatted for the answer boxes shown at the top of search results." },
      { t: "Structured data & schema review", d: "We audit and recommend schema markup such as FAQ, HowTo, Product and Organization." },
      { t: "Voice search readiness", d: "Conversational, concise answers suited to how people phrase spoken questions." },
      { t: "Clear & direct answer formatting", d: "Consistent formatting patterns that make answers easy to scan, quote and reuse." },
    ],
    benefits: [
      "Content that answers buyer questions directly",
      "Better eligibility for featured snippets and rich results",
      "Pages ready for voice and conversational search",
      "Fewer unanswered questions slowing down purchase decisions",
    ],
    cta: "Plan My AEO Strategy",
    faqs: [
      ["How is AEO different from SEO?", "SEO makes your whole website discoverable and rankable. AEO focuses specifically on question-and-answer content, so a page can be selected as the direct answer in snippets, voice results or answer engines."],
      ["Does schema markup guarantee rich results?", "No. Structured data helps search engines understand your content, but they decide whether to display rich results. We make sure your markup is valid and appropriate."],
    ],
  },
  {
    to: "/ai-content-strategy",
    tag: "Content",
    name: "AI-Ready Content Strategy",
    short: "Content planned for search, AI and answers",
    icon: PenLine,
    primary: false,
    intro:
      "Plan, create and optimise content that serves your readers first while remaining easy for search engines and AI systems to interpret.",
    overview: [
      "Good content strategy now has three audiences: the person reading, the search engine ranking, and the AI system summarising. We plan content that works for all three without sounding robotic.",
      "That includes refreshing existing pages, identifying topics worth creating, and setting editorial guidelines that keep facts, structure and tone consistent.",
    ],
    offerings: [
      { t: "Topic & content planning", d: "A content roadmap built from search demand, customer questions and your business priorities." },
      { t: "Content optimization", d: "Existing pages updated for clarity, accuracy, structure and current search intent." },
      { t: "Editorial guidelines", d: "Standards for structure, tone and factual consistency that your team can follow." },
      { t: "Content briefs", d: "Detailed briefs covering intent, questions to answer, structure and internal links." },
    ],
    benefits: ["Content with a clear purpose", "Consistent brand facts across pages", "Better reuse by AI and answer engines", "Less wasted writing effort"],
    cta: "Discuss a Content Plan",
    faqs: [],
  },
  {
    to: "/search-intelligence",
    tag: "Insights",
    name: "Search Intelligence & Analytics",
    short: "Competitor and visibility insights",
    icon: Radar,
    primary: false,
    intro:
      "Understand where you are visible across search and AI platforms, how you compare with competitors, and which actions are worth prioritising.",
    overview: [
      "Visibility is no longer a single ranking number. We bring together search performance data, AI answer checks and competitor analysis into one clear view.",
      "The goal is practical: show what is working, what is not, and what to do next — without drowning you in dashboards.",
    ],
    offerings: [
      { t: "Search visibility analysis", d: "Where your brand appears across organic results, snippets and AI answers for your priority topics." },
      { t: "Competitor analysis", d: "Which competitors appear where you don't, and the content or signals behind their visibility." },
      { t: "Analytics & reporting setup", d: "Search Console and analytics configured so the right search metrics are captured." },
      { t: "Monthly insight reports", d: "Plain-language reports that explain changes and recommend next steps." },
    ],
    benefits: ["One view of search and AI visibility", "Clear competitor context", "Decisions grounded in data", "Reports your team can act on"],
    cta: "Request a Visibility Analysis",
    faqs: [],
  },
  {
    to: "/technical-optimization",
    tag: "Technical",
    name: "Technical Website Optimization",
    short: "Speed, structure and crawlability",
    icon: Gauge,
    primary: false,
    intro:
      "Fix the technical issues that make your website slow, hard to crawl or difficult for search engines and AI systems to read.",
    overview: [
      "Even excellent content underperforms if pages load slowly, render poorly or block crawlers. Technical optimisation removes those barriers.",
      "We review performance, rendering, structured data, accessibility basics and site health, then work with your developers or platform to implement fixes.",
    ],
    offerings: [
      { t: "Performance & Core Web Vitals", d: "Loading speed, interactivity and layout stability improved on key templates." },
      { t: "Crawl & render review", d: "We check how crawlers see your pages, including JavaScript rendering and blocked resources." },
      { t: "Structured data implementation", d: "Valid schema added or corrected so your content's meaning is explicit." },
      { t: "Site health monitoring", d: "Ongoing checks for broken links, redirect chains and indexing problems." },
    ],
    benefits: ["Faster, more stable pages", "Fewer crawl and indexing issues", "Machine-readable content", "A healthier site over time"],
    cta: "Book a Technical Review",
    faqs: [],
  },
];

export const primaryServices = services.filter((s) => s.primary);
export const supportingServices = services.filter((s) => !s.primary);

export const contact = {
  phones: ["+91 95355 01234", "+91-96765 63991"],
  email: "info@vreachall.com",
  address:
    "Flat no 406, 4th floor, SBR Gateway, HUDA Techno Enclave, near Medicover Hospital, HITEC City, Telangana 500081",
  hours: ["Monday – Friday: 9:00 AM – 6:00 PM", "Saturday: 10:00 AM – 4:00 PM"],
};

export const process = [
  { t: "Visibility audit", d: "We review your website, search performance and how AI platforms currently describe your brand." },
  { t: "Search visibility strategy", d: "A prioritised plan across SEO, GEO and AEO, tied to your goals and the questions your customers ask." },
  { t: "Implementation", d: "Technical fixes, content improvements, structured data and entity updates delivered in focused sprints." },
  { t: "Measure & refine", d: "We track search and AI visibility signals, report what changed and adjust the plan." },
];

export const faqs: [string, string][] = [
  ["What is the difference between SEO, GEO and AEO?", "SEO (Search Engine Optimization) helps your website rank in traditional search results. GEO (Generative Engine Optimization) improves how AI platforms like ChatGPT and Gemini understand and mention your brand. AEO (Answer Engine Optimization) structures your content so it can be selected as a direct answer in featured snippets, voice search and answer engines."],
  ["Why isn't traditional SEO enough anymore?", "Search results now include AI summaries, answer boxes and conversational tools that often respond before anyone clicks. SEO is still the foundation, but GEO and AEO help your brand stay visible in these newer formats too."],
  ["What is AI search visibility?", "It describes how often, and how accurately, AI-powered platforms mention or reference your brand when people ask questions related to what you offer."],
  ["Can you guarantee rankings or AI citations?", "No. Search engines and AI platforms control their own results. We improve the factors you can influence, monitor results closely and report honestly on progress."],
  ["How do you measure SEO, GEO and AEO performance?", "We combine search data such as impressions, clicks and rankings with regular AI answer checks, brand mention tracking, featured snippet presence and structured data health."],
  ["Will you make changes to my website directly?", "Only with your approval. We can implement changes with access you provide, or deliver clear recommendations for your developers and content team."],
  ["How do I get started?", "Request a free SEO audit. We will review your website and current visibility, then recommend the most useful next steps across SEO, GEO and AEO."],
  ["How much do your services cost?", "Every engagement is scoped to your website, market and goals, so we prepare a custom proposal after an initial review. Visit the pricing page to see the engagement options."],
];
