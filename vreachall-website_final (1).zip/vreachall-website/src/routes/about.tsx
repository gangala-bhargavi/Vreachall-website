import { createFileRoute, Link } from "@tanstack/react-router";
import { Target, Eye, Compass, ShieldCheck, Layers, MessageCircleQuestion, BarChart3, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageShell, PageHero, SectionHead, CtaBand } from "@/components/site/SiteChrome";

const title = "About VReachAll — AI-First Search Visibility Agency";
const description =
  "Learn about VReachAll, a Hyderabad-based search visibility agency focused on SEO, GEO and AEO — our mission, vision and approach to modern search.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

const approach = [
  { i: Layers, t: "Foundation before tactics", d: "We fix technical and structural issues first, because every other improvement depends on a site that search engines can read." },
  { i: MessageCircleQuestion, t: "Questions over keywords", d: "We build around what your customers actually ask, then make sure your answers are clear enough to be chosen." },
  { i: Compass, t: "Consistent brand signals", d: "We make your business easy to describe — the same facts, services and expertise everywhere it appears." },
  { i: BarChart3, t: "Measured, not assumed", d: "We record a baseline, track search and AI visibility signals, and adjust the plan based on what we see." },
];

function About() {
  return (
    <PageShell>
      <PageHero eyebrow="About Us" title={<>Helping businesses be found <span className="text-gradient-orange">wherever customers ask</span></>}
        sub="VReachAll is an AI-first search visibility and digital growth agency based in HITEC City, Hyderabad. We focus on SEO, GEO and AEO — the three disciplines that decide how businesses are discovered in search engines and AI-powered answers." />

      <section className="mx-auto max-w-4xl px-4 pt-20 sm:px-6" aria-labelledby="focus-title">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent">Our focus</p>
        <h2 id="focus-title" className="mt-2 text-3xl font-bold sm:text-4xl">Search has changed. Our work changed with it.</h2>
        <p className="mt-4 text-lg leading-relaxed text-muted-foreground">People no longer find businesses only through a list of blue links. They read AI summaries, get direct answers in search results and ask assistants for recommendations. We help businesses stay visible across all of these — with SEO as the foundation, AEO for direct answers and GEO for AI-generated responses.</p>
        <p className="mt-4 text-lg leading-relaxed text-muted-foreground">We deliberately keep our focus narrow. Rather than offering every marketing channel, we concentrate on search visibility and the content, analytics and technical work that supports it.</p>
      </section>

      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-20 sm:px-6 md:grid-cols-2">
        {[
          { i: Target, t: "Our Mission", d: "To help businesses be clearly understood and easily found — in search engines, in answer boxes and in AI-generated responses — through honest, well-structured search visibility work." },
          { i: Eye, t: "Our Vision", d: "A web where useful businesses are discoverable on their merits, and where the information search and AI platforms share about them is accurate and up to date." },
        ].map(({ i: I, t, d }) => (
          <div key={t} className="rounded-3xl border border-border bg-card p-8 shadow-soft">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-orange text-primary-foreground"><I size={22} /></span>
            <h2 className="mt-5 text-2xl font-bold">{t}</h2>
            <p className="mt-3 text-muted-foreground">{d}</p>
          </div>
        ))}
      </section>

      <section className="bg-secondary/60" aria-labelledby="approach-title">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <SectionHead eyebrow="Our approach" title="How we approach modern search visibility" />
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {approach.map(({ i: I, t, d }) => (
              <div key={t} className="rounded-2xl bg-card p-6 shadow-soft">
                <I className="text-primary" size={24} />
                <h3 className="mt-4 font-semibold">{t}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-20 text-center sm:px-6">
        <ShieldCheck className="mx-auto text-accent" size={32} />
        <h2 className="mt-4 text-3xl font-bold sm:text-4xl">What you can expect from us</h2>
        <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
          Clear explanations instead of jargon, recommendations tied to your business goals, and honest reporting. We never promise guaranteed rankings or AI citations — we focus on the work that makes them more likely and show you exactly what we've done.
        </p>
        <Button asChild variant="hero" size="xl" className="mt-8"><Link to="/services">Explore Our Services <ArrowRight size={18} /></Link></Button>
      </section>
      <CtaBand />
    </PageShell>
  );
}
