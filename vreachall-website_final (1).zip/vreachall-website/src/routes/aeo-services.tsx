import { createFileRoute } from "@tanstack/react-router";
import { ServicePage, serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/aeo-services")({
  head: () => serviceHead("/aeo-services"),
  component: () => <ServicePage to="/aeo-services" />,
});
