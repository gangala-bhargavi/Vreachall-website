import { createFileRoute } from "@tanstack/react-router";
import { ServicePage, serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/ai-content-strategy")({
  head: () => serviceHead("/ai-content-strategy"),
  component: () => <ServicePage to="/ai-content-strategy" />,
});
