import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ClipboardCheck, LineChart, FileText, Scale } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageShell, PageHero, SectionHead, CtaBand } from "@/components/site/SiteChrome";
import { process } from "@/components/site/data";

const title = "Case Studies & Methodology — VReachAll";
const description =
  "How VReachAll plans, delivers and measures SEO, GEO and AEO engagements, and what every documented case study includes.";

export const Route = createFileRoute("/case-studies")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CaseStudies,
});

const pillars = [
  { i: ClipboardCheck, t: "Documented baseline", d: "Every engagement starts by recording current search, answer and AI visibility." },
  { i: LineChart, t: "Tracked signals", d: "The same metrics are measured over time, so change is visible and comparable." },
  { i: Scale, t: "Verified results only", d: "We publish outcomes only with client approval and supporting data." },
];

const includes = [
  ["The starting point", "The business context, goals and the visibility baseline we recorded."],
  ["What we found", "The key issues and opportunities identified across SEO, GEO and AEO."],
  ["What we did", "The specific changes delivered, in the order we prioritised them."],
  ["What changed", "Measured movement in the agreed metrics, with the time period and data source."],
];

function CaseStudies() {
  return (
    <PageShell>
      <PageHero eyebrow="Case Studies" title={<>Our methodology, <span className="text-gradient-orange">openly explained</span></>}
        sub="We're building our library of verified case studies. Until each one is approved for publication, here is exactly how we run and measure every engagement." />

      <section className="mx-auto grid max-w-5xl gap-5 px-4 pt-20 sm:grid-cols-3 sm:px-6">
        {pillars.map(({ i: I, t, d }) => (
          <div key={t} className="rounded-2xl border border-border bg-card p-8 text-center shadow-soft">
            <I className="mx-auto text-accent" size={32} />
            <h2 className="mt-4 font-display text-lg font-bold">{t}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{d}</p>
          </div>
        ))}
      </section>

      <section className="mx-auto max-w-4xl px-4 py-20 sm:px-6" aria-labelledby="includes-title">
        <SectionHead eyebrow="Case study format" title="What every published case study includes" />
        <div className="mt-10 rounded-3xl bg-ink p-8 text-ink-foreground sm:p-12">
          <FileText className="text-accent" size={32} />
          <ol className="mt-6 grid gap-6 sm:grid-cols-2">
            {includes.map(([t, d], i) => (
              <li key={t}><p className="font-display text-sm font-bold text-accent">0{i + 1}</p><p className="mt-1 font-semibold">{t}</p><p className="mt-1 text-sm text-ink-foreground/70">{d}</p></li>
            ))}
          </ol>
        </div>
      </section>

      <section className="bg-secondary/60">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <SectionHead eyebrow="Our process" title="How every engagement is delivered" />
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {process.map((p, i) => (
              <div key={p.t} className="rounded-2xl bg-card p-6 shadow-soft">
                <span className="font-display text-3xl font-extrabold text-primary">0{i + 1}</span>
                <h3 className="mt-3 font-semibold">{p.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{p.d}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <p className="text-muted-foreground">Want to see how this would apply to your website? We'll walk you through it.</p>
            <Button asChild variant="hero" size="xl" className="mt-5"><Link to="/contact" search={{ service: "Methodology walkthrough" }}>Request a Walkthrough <ArrowRight size={18} /></Link></Button>
          </div>
        </div>
      </section>
      <CtaBand />
    </PageShell>
  );
}
