import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PageShell, PageHero } from "@/components/site/SiteChrome";
import { contact, services } from "@/components/site/data";

const title = "Contact VReachAll — Get a Free SEO Audit";
const description =
  "Talk to VReachAll about SEO, GEO and AEO. Request a free SEO audit or a proposal — call, email or visit us in HITEC City, Hyderabad.";

type ContactSearch = { service?: string | undefined; website?: string | undefined };

export const Route = createFileRoute("/contact")({
  validateSearch: (s: Record<string, unknown>): ContactSearch => ({
    service: typeof s["service"] === "string" ? s["service"].slice(0, 80) : undefined,
    website: typeof s["website"] === "string" ? s["website"].slice(0, 200) : undefined,
  }),
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Contact,
});

const enquiryTypes = [
  "Free SEO Audit",
  ...services.map((s) => s.name),
  "Integrated SEO + GEO + AEO",
  "Methodology walkthrough",
  "Not sure yet",
];

function Contact() {
  const search = Route.useSearch();
  const initialService = search.service && enquiryTypes.includes(search.service) ? search.service : "";
  const [f, setF] = useState({ name: "", email: "", phone: "", website: search.website ?? "", service: initialService, message: "" });
  const [err, setErr] = useState("");
  const [sent, setSent] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!f.name.trim() || !/^\S+@\S+\.\S+$/.test(f.email) || !f.message.trim()) {
      setErr("Please fill in your name, a valid email and a message.");
      return;
    }
    setErr("");
    const body = `Name: ${f.name}\nEmail: ${f.email}\nPhone: ${f.phone}\nWebsite: ${f.website || "Not provided"}\nEnquiry: ${f.service || "Not specified"}\n\n${f.message}`;
    const subject = `${f.service || "Search visibility enquiry"} — ${f.name}`;
    window.location.href = `mailto:${contact.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setSent(true);
  };

  const info = [
    { i: MapPin, t: "Visit us", lines: [contact.address] },
    { i: Phone, t: "Call us", lines: contact.phones },
    { i: Mail, t: "Email us", lines: [contact.email] },
    { i: Clock, t: "Working hours", lines: contact.hours },
  ];

  return (
    <PageShell>
      <PageHero eyebrow="Contact Us" title={<>Let's make your business <span className="text-gradient-orange">easier to find</span></>}
        sub="Ask about SEO, GEO or AEO, request a free SEO audit, or tell us what you're trying to achieve. We'll reply with practical next steps." />
      <section className="mx-auto grid max-w-7xl gap-8 px-4 py-20 sm:px-6 lg:grid-cols-[1fr_1.3fr]">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
          {info.map(({ i: I, t, lines }) => (
            <div key={t} className="flex gap-4 rounded-2xl border border-border bg-card p-5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><I size={20} /></span>
              <div><p className="font-semibold">{t}</p>{lines.map((l) => <p key={l} className="text-sm text-muted-foreground">{l}</p>)}</div>
            </div>
          ))}
        </div>
        <form onSubmit={submit} className="rounded-3xl border border-border bg-card p-6 shadow-soft sm:p-8" noValidate>
          <h2 className="text-2xl font-bold">Send us an enquiry</h2>
          <p className="mt-1 text-sm text-muted-foreground">Include your website and we'll take an initial look at your search and AI visibility before we reply.</p>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <Input aria-label="Your name" autoComplete="name" required placeholder="Your name *" value={f.name} onChange={set("name")} className="h-11" />
            <Input aria-label="Email" autoComplete="email" required placeholder="Email *" type="email" value={f.email} onChange={set("email")} className="h-11" />
            <Input aria-label="Phone" autoComplete="tel" type="tel" placeholder="Phone" value={f.phone} onChange={set("phone")} className="h-11" />
            <Input aria-label="Website" autoComplete="url" placeholder="Your website (e.g. yourbrand.com)" value={f.website} onChange={set("website")} className="h-11" />
            <select aria-label="What can we help with?" value={f.service} onChange={set("service")} className="h-11 rounded-md border border-input bg-background px-3 text-sm sm:col-span-2">
              <option value="">What can we help with?</option>
              {enquiryTypes.map((t) => <option key={t}>{t}</option>)}
            </select>
            <Textarea aria-label="Your message" required placeholder="Tell us about your business, goals and the searches or questions you want to be found for *" value={f.message} onChange={set("message")} className="min-h-32 sm:col-span-2" />
          </div>
          {err && <p role="alert" className="mt-3 text-sm text-destructive">{err}</p>}
          {sent && <p role="status" className="mt-3 text-sm text-success">Your enquiry is prepared, not sent. Send it from your email app, or email <a className="underline" href={`mailto:${contact.email}`}>{contact.email}</a> directly.</p>}
          <Button type="submit" variant="hero" size="xl" className="mt-6 w-full sm:w-auto">Send Enquiry <Send size={18} /></Button>
        </form>
      </section>
    </PageShell>
  );
}
