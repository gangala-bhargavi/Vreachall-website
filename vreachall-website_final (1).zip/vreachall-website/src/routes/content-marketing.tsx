import { createFileRoute, redirect } from "@tanstack/react-router";

// Former service page; permanently points visitors and search engines to its replacement.
export const Route = createFileRoute("/content-marketing")({
  beforeLoad: () => {
    throw redirect({ to: "/ai-content-strategy", statusCode: 301 });
  },
});
