import { createFileRoute } from "@tanstack/react-router";
import { ServicePage, serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/geo-services")({
  head: () => serviceHead("/geo-services"),
  component: () => <ServicePage to="/geo-services" />,
});
