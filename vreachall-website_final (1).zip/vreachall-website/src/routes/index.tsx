import { createFileRoute } from "@tanstack/react-router";
import { PageShell, JsonLd } from "@/components/site/SiteChrome";
import { Hero } from "@/components/home/Hero";
import { Problem, Pillars, HowItWorks, Discoverability, Analytics, Commitments, Compare, Faq, FinalCta } from "@/components/home/Sections";
import { faqs } from "@/components/site/data";

const title = "VReachAll — SEO, GEO & AEO Agency | Be the Answer Everywhere";
const description =
  "VReachAll is an AI-first search visibility agency. We combine SEO, Generative Engine Optimization and Answer Engine Optimization to help businesses get found in search and AI answers.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })),
};

function Index() {
  return (
    <PageShell>
      <JsonLd data={faqSchema} />
      <Hero />
      <Problem />
      <Pillars />
      <HowItWorks />
      <Discoverability />
      <Analytics />
      <Commitments />
      <Compare />
      <Faq />
      <FinalCta />
    </PageShell>
  );
}
