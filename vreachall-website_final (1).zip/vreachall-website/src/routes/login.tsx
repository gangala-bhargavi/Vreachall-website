import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/login")({
  validateSearch: (s: Record<string, unknown>) => ({ mode: s["mode"] === "signup" ? "signup" : undefined }) as { mode?: "signup" },
  head: () => ({
    meta: [
      { title: "Client Login — VReachAll" },
      { name: "description", content: "Sign in to your VReachAll client account to follow your SEO, GEO and AEO work." },
      { property: "og:title", content: "Client Login — VReachAll" },
      { property: "og:description", content: "Sign in to your VReachAll client account to follow your SEO, GEO and AEO work." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Login,
});

function Login() {
  const { mode } = Route.useSearch();
  const signup = mode === "signup";
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr("Enter a valid email address.");
    if (pw.length < 8) return setErr("Password must be at least 8 characters.");
    setErr(null);
    setMsg("Demo mode: accounts aren't connected yet, so nothing was saved.");
  };

  return (
    <div className="grid min-h-screen place-items-center bg-hero px-4">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-soft">
        <Link to="/" aria-label="VReachAll home" className="flex justify-center"><Logo size="lg" tagline /></Link>
        <h1 className="mt-6 text-center text-2xl font-bold">{signup ? "Create your account" : "Welcome back"}</h1>
        <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
          <Input aria-label="Email address" autoComplete="email" type="email" placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11" />
          <Input aria-label="Password" autoComplete={signup ? "new-password" : "current-password"} type="password" placeholder="Password" value={pw} onChange={(e) => setPw(e.target.value)} className="h-11" />
          {err && <p className="text-sm text-destructive">{err}</p>}
          {msg && <p className="rounded-lg bg-secondary p-3 text-sm text-secondary-foreground">{msg}</p>}
          <Button type="submit" variant="hero" size="xl" className="w-full">{signup ? "Create account" : "Sign in"}</Button>
        </form>
        <p className="mt-5 text-center text-sm text-muted-foreground">
          {signup ? "Already have an account? " : "New to VReachAll? "}
          <Link to="/login" search={signup ? {} : { mode: "signup" }} className="font-medium text-primary">{signup ? "Sign in" : "Create one"}</Link>
        </p>
      </div>
    </div>
  );
}
