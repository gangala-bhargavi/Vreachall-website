import { createFileRoute, redirect } from "@tanstack/react-router";

// Former service page; permanently points visitors and search engines to its replacement.
export const Route = createFileRoute("/ppc-management")({
  beforeLoad: () => {
    throw redirect({ to: "/services", statusCode: 301 });
  },
});
