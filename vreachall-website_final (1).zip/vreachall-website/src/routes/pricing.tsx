import { createFileRoute } from "@tanstack/react-router";
import { PageShell, CtaBand } from "@/components/site/SiteChrome";
import { PricingSection } from "@/components/site/PricingSection";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing & Engagement Options — VReachAll" },
      { name: "description", content: "Custom-scoped SEO, GEO, AEO and integrated search visibility engagements from VReachAll. Request a tailored proposal." },
      { property: "og:title", content: "Pricing & Engagement Options — VReachAll" },
      { property: "og:description", content: "Custom-scoped SEO, GEO, AEO and integrated search visibility engagements. Request a tailored proposal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <PageShell>
      <PricingSection />
      <CtaBand />
    </PageShell>
  ),
});
