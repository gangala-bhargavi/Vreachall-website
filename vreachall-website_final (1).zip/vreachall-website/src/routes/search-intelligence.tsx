import { createFileRoute } from "@tanstack/react-router";
import { ServicePage, serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/search-intelligence")({
  head: () => serviceHead("/search-intelligence"),
  component: () => <ServicePage to="/search-intelligence" />,
});
