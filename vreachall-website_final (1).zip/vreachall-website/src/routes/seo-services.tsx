import { createFileRoute } from "@tanstack/react-router";
import { ServicePage, serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/seo-services")({
  head: () => serviceHead("/seo-services"),
  component: () => <ServicePage to="/seo-services" />,
});
