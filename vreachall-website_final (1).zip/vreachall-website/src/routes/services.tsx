import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageShell, PageHero, SectionHead, CtaBand } from "@/components/site/SiteChrome";
import { primaryServices, supportingServices } from "@/components/site/data";

const title = "SEO, GEO & AEO Services — VReachAll";
const description =
  "Explore VReachAll's core services — Search Engine Optimization, Generative Engine Optimization and Answer Engine Optimization — plus supporting content, analytics and technical services.";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Services,
});

function Services() {
  return (
    <PageShell>
      <PageHero eyebrow="Services" title={<>Search visibility for the <span className="text-gradient-orange">age of AI answers</span></>}
        sub="Three core disciplines — SEO, GEO and AEO — working together so your business can be found, understood and chosen wherever customers search.">
        <Button asChild variant="hero" size="xl"><Link to="/contact" search={{ service: "Free SEO Audit" }}>Get Free SEO Audit <ArrowRight size={18} /></Link></Button>
      </PageHero>

      <section className="mx-auto max-w-7xl space-y-6 px-4 py-20 sm:px-6" aria-label="Core services">
        {primaryServices.map((s, i) => (
          <article key={s.to} className="grid gap-8 rounded-3xl border border-border bg-card p-8 shadow-soft transition hover:-translate-y-0.5 md:p-10 lg:grid-cols-[auto_1.1fr_1fr]">
            <span className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-orange text-primary-foreground shadow-orange"><s.icon size={28} /></span>
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-accent">Core service 0{i + 1} · {s.tag}</p>
              <h2 className="mt-1 text-2xl font-bold sm:text-3xl">{s.name}</h2>
              <p className="mt-3 text-muted-foreground">{s.intro}</p>
              <h3 className="mt-6 text-sm font-semibold">Key benefits</h3>
              <ul className="mt-2 space-y-1.5 text-sm text-muted-foreground">{s.benefits.map((b) => <li key={b} className="flex gap-2"><Check size={16} className="mt-0.5 shrink-0 text-success" />{b}</li>)}</ul>
              <div className="mt-6 flex flex-wrap gap-3">
                <Button asChild variant="hero"><Link to="/contact" search={{ service: s.name }}>{s.cta} <ArrowRight /></Link></Button>
                <Button asChild variant="outline" className="rounded-full"><Link to={s.to}>View {s.tag} details</Link></Button>
              </div>
            </div>
            <div className="rounded-2xl bg-secondary/70 p-6">
              <h3 className="text-sm font-semibold">What's included</h3>
              <ul className="mt-4 grid gap-2.5 text-sm">{s.offerings.map((o) => <li key={o.t} className="flex items-center gap-2"><Check size={16} className="shrink-0 text-primary" />{o.t}</li>)}</ul>
            </div>
          </article>
        ))}
      </section>

      <section className="bg-secondary/60" aria-labelledby="supporting-title">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <SectionHead eyebrow="Supporting services" title="Everything that strengthens your visibility" sub="Specialist services that support and amplify your SEO, GEO and AEO work." />
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {supportingServices.map((s) => (
              <Link key={s.to} to={s.to} className="group flex flex-col rounded-2xl border border-border bg-card p-6 transition hover:-translate-y-1 hover:shadow-soft">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary"><s.icon size={22} /></span>
                <h3 className="mt-4 text-lg font-semibold">{s.name}</h3>
                <p className="mt-2 flex-1 text-sm text-muted-foreground">{s.intro}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary transition-all group-hover:gap-2">Learn more <ArrowRight size={16} /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <CtaBand />
    </PageShell>
  );
}
