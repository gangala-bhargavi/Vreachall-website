import { createFileRoute } from "@tanstack/react-router";
import { ServicePage, serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/technical-optimization")({
  head: () => serviceHead("/technical-optimization"),
  component: () => <ServicePage to="/technical-optimization" />,
});
