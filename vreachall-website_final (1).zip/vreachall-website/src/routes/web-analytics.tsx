import { createFileRoute, redirect } from "@tanstack/react-router";

// Former service page; permanently points visitors and search engines to its replacement.
export const Route = createFileRoute("/web-analytics")({
  beforeLoad: () => {
    throw redirect({ to: "/search-intelligence", statusCode: 301 });
  },
});
