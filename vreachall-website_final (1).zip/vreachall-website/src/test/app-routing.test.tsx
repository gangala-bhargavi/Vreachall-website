import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";
import { primaryServices, services } from "@/components/site/data";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it.each([
    "/", "/about", "/services", "/seo-services", "/geo-services", "/aeo-services",
    "/ai-content-strategy", "/search-intelligence", "/technical-optimization",
    "/case-studies", "/contact", "/login", "/pricing",
  ])("matches the exact website page %s", (path) => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
    expect(router.matchRoutes(path).at(-1)?.routeId).toBe(path);
  });

  it.each(["/ppc-management", "/social-media-marketing", "/content-marketing", "/email-marketing", "/web-analytics"])(
    "keeps the old service address %s reachable",
    (path) => {
      const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
      expect(router.matchRoutes(path).at(-1)?.routeId).toBe(path);
    },
  );

  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
    const matches = router.matchRoutes("/");
    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });
});

describe("Service positioning", () => {
  it("lists SEO, GEO and AEO as the only primary services, in that order", () => {
    expect(primaryServices.map((s) => s.tag)).toEqual(["SEO", "GEO", "AEO"]);
  });

  it("gives every service its own description", () => {
    const intros = services.map((s) => s.intro);
    expect(new Set(intros).size).toBe(intros.length);
  });
});
